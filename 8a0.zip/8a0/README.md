# 8a0 ⚽

A browser-based Champions League fantasy team-builder. Draft club by club, build your dream XI, and try to go a perfect 8 for 8.

[🇧🇷 Versão em português](README.pt-BR.md)

---

## What is this?

You draft 11 players across 60 real Champions League club-seasons spanning from the 1950s to the 2020s — from Real Madrid's 7–3 final in 1960 to PSG's modern era. Each round, a random club is offered and you pick any player from their full squad for any compatible slot on your pitch. No real player can ever be drafted twice.

Once your squad is set, you play 8 matches: 3 group-stage games, then 16th-finals through to the final. Win all 8 and you've made it — an 8 a 0 perfect run.

## How to play

1. **Name your team and pick a formation** — 9 tactical formations available (4-3-3, 4-2-3-1, 4-4-2, 3-5-2, 3-4-3, 4-1-4-1, 5-3-2, 4-1-2-1-2, 3-4-2-1). Locked in once the draft starts.
2. **Choose your mode:**
   - **Classic** — overalls visible the whole time, draft with full information.
   - **Challenge** — overalls hidden until your squad is complete. You draft blind, by name and position only, then get a big reveal at the end.
3. **Draft** — 11 rounds. Each round offers a full club squad; pick anyone who fits an open or occupied slot. You can freely reorganize players between compatible slots at any time.
4. **Group stage** — 3 matches against 3 rival clubs. The rivals also play each other progressively, one extra fixture revealed alongside each of your games, so the table is fully real by the end.
5. **Knockouts** — 16th-finals, round of 16, quarters, semis, final. Draws go to a full shooter-by-shooter penalty shootout.
6. **Final summary** — top scorer, top assister, and your full squad's stats and overalls, ordered by position from keeper to striker.

## Features

- **60 club-seasons**, all of them real Champions League / European Cup participants (with two explicitly-flagged exceptions for legendary squads that never reached a final)
- **9 formations**, each with its own pitch layout
- Players who appear in multiple club-seasons have differentiated overalls reflecting their career stage (young breakout vs. peak vs. veteran)
- **Realistic penalty shootouts** — attackers and midfielders shoot first, conversion chance scales with overall, alternating sides, true sudden death with no artificial cutoff
- Goal-by-goal match events with scorer, assister, and minute
- Progressive group table — rival-vs-rival fixtures play out across the 3 rounds, not all at once
- Tuned so a perfect 8–0 run happens roughly 1–3% of the time

## Running it

It's a static site — no build step, no server required.

```bash
# just open it
open index.html
```

Or serve it locally if you prefer:

```bash
python3 -m http.server 8000
# then visit localhost:8000
```

## Project structure

```
8a0/
├── index.html          # all 5 screens (landing, mode select, draft, group, knockout, summary)
├── assets/
│   ├── data.js          # club-season database, formations, position-compatibility logic
│   ├── engine.js        # game state, draft logic, match simulation, standings
│   ├── ui.js             # rendering and event handlers
│   ├── style.css         # visual theme
│   └── images/
```

## Disclaimer

Unofficial fan project. Player data and overalls are approximate, built for entertainment — not a historical or statistical record.
