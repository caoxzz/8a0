/* ============================================================
   8A0 — UI / CONTROLLER
   ============================================================ */

function $(sel) {
  return document.querySelector(sel);
}
function showScreen(id) {
  document.querySelectorAll(".screen").forEach((s) => s.classList.remove("active"));
  $(id).classList.add("active");
}
function lastName(full) {
  const parts = full.split(" ");
  return parts[parts.length - 1];
}

/* ---------- estrelinhas decorativas do hero ---------- */
(function seedStars() {
  const box = $("#stars-bg");
  if (!box) return;
  for (let i = 0; i < 18; i++) {
    const s = document.createElement("span");
    s.style.left = Math.random() * 100 + "%";
    s.style.top = Math.random() * 100 + "%";
    s.style.opacity = (0.2 + Math.random() * 0.6).toFixed(2);
    box.appendChild(s);
  }
})();

/* ---------- TELA: LANDING -> ESCOLHA DE MODO -> DRAFT ---------- */
$("#btn-start").addEventListener("click", () => {
  showScreen("#screen-mode");
  renderFormationGrid();
});

let selectedFormation = "4-3-3";

function renderFormationGrid() {
  const grid = $("#formation-grid");
  const names = Object.keys(FORMATIONS);
  grid.innerHTML = names
    .map(
      (name) => `
        <button class="formation-card ${name === selectedFormation ? "selected" : ""}" data-formation="${name}">
          ${name}
        </button>
      `
    )
    .join("");
  grid.querySelectorAll(".formation-card").forEach((btn) => {
    btn.addEventListener("click", () => {
      selectedFormation = btn.dataset.formation;
      renderFormationGrid();
    });
  });
}

$("#mode-classic").addEventListener("click", () => {
  startDraftWithMode("classic");
});
$("#mode-challenge").addEventListener("click", () => {
  startDraftWithMode("challenge");
});

function startDraftWithMode(mode) {
  const typedName = $("#team-name-input").value.trim();
  initBuilder(selectedFormation);
  state.gameMode = mode;
  state.teamName = typedName.length ? typedName : "Meu Time";
  showScreen("#screen-draft");
  renderDraft();
}

/* ---------- TELA: DRAFT (sorteio + escolha, tudo numa tela) ---------- */
function renderDraft() {
  const hideOvr = state.gameMode === "challenge" && !isDraftComplete();
  const ovrLabel = hideOvr ? "?" : currentSquadOvr() ? currentSquadOvr().toFixed(1) : "0";
  const modeTag = state.gameMode === "challenge" ? "MODO CHALLENGE" : "MODO CLÁSSICO";
  $("#draft-meta").innerHTML = `<span>${modeTag}</span><span>FORMAÇÃO ${state.myFormation}</span><span>OVR ${ovrLabel}</span>`;
  renderPitchSlots();
  renderOfferZone();
  renderSquadMiniList();

  $("#draft-count").textContent = `${state.draftIndex}/11`;

  if (isDraftComplete()) {
    if (state.gameMode === "challenge" && !state.revealedAfterDraft) {
      state.revealedAfterDraft = true;
      renderRevealMoment();
      return;
    }
    $("#offer-zone").innerHTML = `<p style="color:var(--silver); font-size:13px;">Time completo! Você já pode seguir pra Champions.</p>`;
    $("#draft-actions").style.display = "flex";
  } else {
    $("#draft-actions").style.display = "none";
  }
}

/* no modo challenge, quando o 11º jogador é escalado, mostra uma revelação
   especial com todos os overalls antes de liberar o botão de seguir */
function renderRevealMoment() {
  const zone = $("#offer-zone");
  const meOvr = currentSquadOvr();
  let rows = state.slots
    .map(
      (s) => `
      <div class="offer-item">
        <div class="oi-left">
          <span class="oi-name">${s.pos} · ${s.player.name}</span>
          <div class="oi-positions">${s.player.positions.map((p) => `<span class="oi-pos">${p}</span>`).join("")}</div>
        </div>
        <span class="oi-ovr">${s.player.ovr}</span>
      </div>
    `
    )
    .join("");

  zone.innerHTML = `
    <div class="offer-card">
      <div class="offer-club">★ Revelação Challenge</div>
      <div class="offer-season">SEU TIME ESTÁ COMPLETO · OVR MÉDIO ${meOvr.toFixed(1)}</div>
      <div class="offer-list">${rows}</div>
    </div>
  `;
  $("#draft-actions").style.display = "flex";

  // atualiza topbar e campo já revelando os overalls
  $("#draft-meta").innerHTML = `<span>MODO CHALLENGE · REVELADO</span><span>FORMAÇÃO ${state.myFormation}</span><span>OVR ${meOvr.toFixed(1)}</span>`;
  renderPitchSlotsRevealed();
}

function renderPitchSlotsRevealed() {
  const board = $("#pitch-board");
  board.querySelectorAll(".slot").forEach((el) => el.remove());
  state.slots.forEach((slot) => {
    const el = document.createElement("div");
    el.className = "slot filled";
    el.style.left = slot.x + "%";
    el.style.top = slot.y + "%";
    el.innerHTML = `
      <div class="slot-dot">
        ${slot.player.ovr}
        <span class="slot-ovr-badge">${slot.pos}</span>
      </div>
      <div class="slot-name">${lastName(slot.player.name)}</div>
    `;
    board.appendChild(el);
  });
}

function renderPitchSlots() {
  const board = $("#pitch-board");
  board.querySelectorAll(".slot").forEach((el) => el.remove());
  const hideOvr = state.gameMode === "challenge";

  state.slots.forEach((slot, idx) => {
    const el = document.createElement("div");
    el.className = "slot " + (slot.player ? "filled" : "empty");
    el.style.left = slot.x + "%";
    el.style.top = slot.y + "%";
    const dotContent = slot.player ? (hideOvr ? "★" : slot.player.ovr) : slot.pos;
    el.innerHTML = `
      <div class="slot-dot">
        ${dotContent}
        ${slot.player ? `<span class="slot-ovr-badge">${slot.pos}</span>` : ""}
      </div>
      <div class="slot-name">${slot.player ? lastName(slot.player.name) : slot.pos}</div>
    `;
    // todo slot é clicável: vazio ou ocupado, abre o organizador manual
    el.addEventListener("click", () => openManualSlotEditor(idx));
    board.appendChild(el);
  });
}

/* clique direto num slot do campo: se ele tem jogador, permite movê-lo
   manualmente pra outra posição vaga compatível dele mesmo. Se está vazio,
   só informa que é preciso esperar uma oferta de draft (não dá pra inventar
   jogador do nada). */
function openManualSlotEditor(slotIndex) {
  document.querySelectorAll(".slot-pick-row").forEach((r) => r.remove());
  const slot = state.slots[slotIndex];
  const zone = $("#offer-zone");

  if (!slot.player) {
    return; // slot vazio: nada pra reorganizar aqui, só recebe via oferta
  }

  const vacancies = vacantCompatibleSlots(slot.player, slotIndex);
  const hideOvr = state.gameMode === "challenge" && !isDraftComplete();
  const ovrTxt = hideOvr ? "?" : slot.player.ovr;

  let html = `
    <div class="offer-card" id="manual-edit-card">
      <div class="offer-club">${slot.pos} · ${slot.player.name}</div>
      <div class="offer-season">OVR ${ovrTxt} · POSIÇÕES: ${slot.player.positions.join(", ")}</div>
  `;
  if (!vacancies.length) {
    html += `<p style="color:var(--silver); font-size:12.5px; margin:10px 0 0;">Esse jogador só joga nessa posição (ou todas as outras compatíveis já estão ocupadas). Não pode ser movido agora.</p>`;
  } else {
    html += `<p style="color:var(--silver); font-size:12.5px; margin:10px 0 8px;">Mover para:</p><div class="slot-pick-row" style="margin-top:0;">`;
    vacancies.forEach((v) => {
      html += `<button class="slot-pick-btn" data-target="${v.idx}">${v.s.pos}</button>`;
    });
    html += `</div>`;
  }
  html += `<button class="btn btn-ghost modal-close" id="btn-cancel-manual-edit" style="margin-top:14px; width:100%;">Fechar</button></div>`;

  zone.innerHTML = html;

  zone.querySelectorAll(".slot-pick-btn[data-target]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetIdx = parseInt(btn.dataset.target, 10);
      manuallyRelocatePlayer(slotIndex, targetIdx);
      renderDraft();
    });
  });
  $("#btn-cancel-manual-edit").addEventListener("click", () => renderDraft());
}

function renderOfferZone() {
  const zone = $("#offer-zone");
  if (!state.currentOffer || isDraftComplete()) {
    zone.innerHTML = "";
    return;
  }
  const cs = state.currentOffer.clubSeason;
  const allPlayers = eligibleOfferPlayers(); // elenco completo, com __eligibleSlots por jogador
  const hideOvr = state.gameMode === "challenge";

  // no modo challenge ordena por nome (sem dar pista de força pela posição na lista)
  const sorted = hideOvr
    ? [...allPlayers].sort((a, b) => a.name.localeCompare(b.name))
    : [...allPlayers].sort((a, b) => b.ovr - a.ovr);

  let html = `
    <div class="offer-card">
      <div class="offer-club">${cs.badge} ${cs.club}</div>
      <div class="offer-season">TEMPORADA ${cs.season} · ELENCO COMPLETO</div>
      <div class="offer-list">
  `;

  sorted.forEach((p, idx) => {
    const isLegend = !hideOvr && p.ovr >= 90;
    const disabled = p.__eligibleSlots.length === 0;
    html += `
      <div class="offer-item ${isLegend ? "legend" : ""} ${disabled ? "offer-item-disabled" : ""}" data-idx="${idx}">
        <div class="oi-left">
          <span class="oi-name">${p.name}</span>
          <div class="oi-positions">
            ${p.positions.map((pos) => `<span class="oi-pos">${pos}</span>`).join("")}
          </div>
        </div>
        ${hideOvr ? `<span class="oi-ovr oi-hidden">?</span>` : `<span class="oi-ovr">${p.ovr}</span>`}
      </div>
    `;
  });

  html += `</div></div>`;
  zone.innerHTML = html;

  // liga clique só nos itens habilitados (com pelo menos 1 slot elegível)
  const items = zone.querySelectorAll(".offer-item:not(.offer-item-disabled)");
  items.forEach((item) => {
    item.addEventListener("click", () => {
      const idx = parseInt(item.dataset.idx, 10);
      const player = sorted[idx];
      openSlotPicker(item, player);
    });
  });
}

function openSlotPicker(itemEl, player) {
  // remove pickers abertos antes
  document.querySelectorAll(".slot-pick-row").forEach((r) => r.remove());

  const row = document.createElement("div");
  row.className = "slot-pick-row";
  player.__eligibleSlots.forEach((choice) => {
    const btn = document.createElement("button");
    btn.className = "slot-pick-btn";
    btn.textContent = choice.displaces ? `${choice.pos} (move ${lastName(choice.displaces.name)})` : `Escalar em ${choice.pos}`;
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      draftPlayerIntoSlot(player, choice.slotIndex);
      renderDraft();
    });
    row.appendChild(btn);
  });
  itemEl.appendChild(row);
}

function renderSquadMiniList() {
  const list = $("#squad-mini-list");
  list.innerHTML = "";
  if (!state.squadPlayers.length) return;
  const hideOvr = state.gameMode === "challenge";
  state.slots
    .filter((s) => s.player)
    .forEach((s) => {
      const row = document.createElement("div");
      row.className = "smi-row";
      const ovrText = hideOvr ? "?" : s.player.ovr;
      row.innerHTML = `<span>${s.pos}</span><b>${s.player.name} · ${ovrText}</b>`;
      list.appendChild(row);
    });
}

$("#btn-go-championship").addEventListener("click", () => {
  generateChampionship();
  showScreen("#screen-group");
  renderGroupTrack();
  renderGroupTable();
  renderGroupMatchScreen();
});

/* ---------- TELA: FASE DE GRUPOS ---------- */
function renderGroupTrack() {
  const track = $("#tournament-track-group");
  track.innerHTML = "";
  STAGES.filter((s) => s.group).forEach((s, i) => {
    const div = document.createElement("div");
    div.className = "tt-stage";
    div.textContent = s.label;
    track.appendChild(div);
  });
  updateGroupTrackStatus();
}
function updateGroupTrackStatus() {
  const els = document.querySelectorAll("#tournament-track-group .tt-stage");
  els.forEach((el, i) => {
    el.classList.remove("done", "fail", "live");
    if (i < state.results.length) {
      el.classList.add(state.results[i].won ? "done" : state.results[i].draw ? "" : "fail");
    } else if (i === state.results.length) {
      el.classList.add("live");
    }
  });
}

function renderGroupTable() {
  const card = $("#group-table-card");
  const standing = computeGroupStanding();
  let html = `<h3>Classificação do Grupo</h3>`;
  html += `<p style="font-family:var(--mono); font-size:11px; color:var(--silver); margin:-6px 0 14px;">A cada rodada, os outros times do grupo também se enfrentam — a tabela evolui junto com os seus jogos.</p>`;
  html += `<div class="gt-row header"><span>Time</span><span>J</span><span>SG</span><span>GP</span><span>Pts</span></div>`;
  standing.sorted.forEach((row, i) => {
    const pos = i + 1;
    const qualified = pos <= 2;
    html += `
      <div class="gt-row ${row.isMe ? "me" : ""} ${qualified ? "gt-qualified" : "gt-eliminated-row"}">
        <span class="gt-team"><span class="gt-pos">${pos}º</span>${row.isMe ? `★ ${state.teamName}` : (row.club.badge + " " + row.name)}</span>
        <span class="gt-num">${row.played}</span>
        <span class="gt-num">${row.gf - row.ga >= 0 ? "+" : ""}${row.gf - row.ga}</span>
        <span class="gt-num">${row.gf}</span>
        <span class="gt-pts">${row.pts}</span>
      </div>
    `;
  });
  card.innerHTML = html;
}

function renderGroupMatchScreen() {
  $("#group-meta").innerHTML = `<span>OVR ${currentSquadOvr().toFixed(1)}</span>`;
  const stageIdx = state.results.length;

  if (stageIdx >= 3) {
    // fim dos 3 jogos: decide classificação
    const standing = computeGroupStanding();
    renderGroupResultGate(standing);
    return;
  }

  const stage = STAGES[stageIdx];
  const rival = state.groupTeams[stageIdx];
  const myOvr = currentSquadOvr();
  const rivalOvr = avgClubOvr(rival);

  const card = $("#group-match-card");
  card.innerHTML = `
    <div class="match-stage-label">${stage.label}</div>
    <div class="match-teams">
      <div class="match-side">
        <div class="badge">★</div>
        <h4>${state.teamName}</h4>
        <div class="ovr">OVR ${myOvr.toFixed(1)}</div>
      </div>
      <div class="match-score"><span>?</span><span class="vs">x</span><span>?</span></div>
      <div class="match-side">
        <div class="badge">${rival.badge}</div>
        <h4>${rival.club}</h4>
        <div class="ovr">OVR ${rivalOvr.toFixed(0)} · ${rival.season}</div>
      </div>
    </div>
    <div class="match-actions">
      <button class="btn btn-primary" id="btn-play-group-match">Apitar o jogo →</button>
    </div>
  `;
  $("#btn-play-group-match").addEventListener("click", () => playGroupCurrentMatch(stageIdx));
}

function playGroupCurrentMatch(stageIdx) {
  const btn = $("#btn-play-group-match");
  if (!btn || btn.dataset.running === "1") return; // proteção contra double-click
  btn.dataset.running = "1";
  btn.disabled = true;
  btn.textContent = "Simulando...";
  setTimeout(() => {
    // confirma que ainda estamos na rodada certa (não foi jogada por outro caminho)
    if (state.results.length !== stageIdx) return;
    const record = playGroupMatch(stageIdx);
    renderGroupMatchResult(record);
    updateGroupTrackStatus();
    renderGroupTable();
  }, 600);
}

function buildGoalEventsHtml(record) {
  const myList = record.myEvents.length
    ? record.myEvents
        .map(
          (ev) =>
            `<div class="ge-event"><span class="ge-min">${ev.minute}'</span><span>⚽ ${ev.scorer}${ev.assister ? `<span class="ge-assist"> (assist. ${ev.assister})</span>` : ""}</span></div>`
        )
        .join("")
    : `<div class="ge-event" style="color:var(--silver);">Sem gols</div>`;

  const rivalList = record.rivalEvents.length
    ? record.rivalEvents
        .map(
          (ev) =>
            `<div class="ge-event"><span class="ge-min">${ev.minute}'</span><span>⚽ ${ev.scorer}${ev.assister ? `<span class="ge-assist"> (assist. ${ev.assister})</span>` : ""}</span></div>`
        )
        .join("")
    : `<div class="ge-event" style="color:var(--silver);">Sem gols</div>`;

  return `
    <div class="goal-events">
      <div class="ge-col">
        <h5>Gols · ${state.teamName}</h5>
        ${myList}
      </div>
      <div class="ge-col">
        <h5>Gols · ${record.rivalLabel}</h5>
        ${rivalList}
      </div>
    </div>
  `;
}

function buildOtherFixtureHtml(record) {
  if (!record.otherFixture) return "";
  const f = record.otherFixture;
  return `
    <div class="other-fixture">
      <span class="other-fixture-label">Também na rodada</span>
      <div class="other-fixture-row">
        <span class="of-team">${f.badgeA} ${f.labelA}</span>
        <span class="of-score">${f.goalsA} x ${f.goalsB}</span>
        <span class="of-team">${f.labelB} ${f.badgeB}</span>
      </div>
    </div>
  `;
}

function renderGroupMatchResult(record) {
  const card = $("#group-match-card");
  let verdict = "";
  if (record.won) verdict = `<div class="match-verdict win">Vitória!</div>`;
  else if (record.draw) verdict = `<div class="match-verdict">Empate.</div>`;
  else verdict = `<div class="match-verdict lose">Derrota.</div>`;

  card.innerHTML = `
    <div class="match-stage-label">${record.stage.label}</div>
    <div class="match-teams">
      <div class="match-side">
        <div class="badge">★</div>
        <h4>${state.teamName}</h4>
        <div class="ovr">OVR ${record.myOvr.toFixed(0)}</div>
      </div>
      <div class="match-score"><span>${record.myGoals}</span><span class="vs">x</span><span>${record.rivalGoals}</span></div>
      <div class="match-side">
        <div class="badge">${record.rivalBadge}</div>
        <h4>${record.rivalLabel}</h4>
        <div class="ovr">OVR ${record.rivalOvr.toFixed(0)}</div>
      </div>
    </div>
    ${verdict}
    ${buildOtherFixtureHtml(record)}
    ${buildGoalEventsHtml(record)}
    <div class="match-actions">
      <button class="btn btn-primary" id="btn-next-group">${state.results.length >= 3 ? "Ver classificação final do grupo →" : "Próximo jogo do grupo →"}</button>
    </div>
  `;
  $("#btn-next-group").addEventListener("click", renderGroupMatchScreen);
}

/* depois dos 3 jogos: mostra se classificou ou foi eliminado matematicamente
   pela posição na tabela (não pelo resultado de um jogo isolado) */
function renderGroupResultGate(standing) {
  const card = $("#group-match-card");
  const meRow = standing.sorted.find((r) => r.isMe);
  const pos = standing.myPos;

  if (standing.qualified) {
    card.innerHTML = `
      <div class="match-stage-label">FIM DA FASE DE GRUPOS</div>
      <div class="match-verdict win" style="margin-top:6px;">Classificado em ${pos}º lugar!</div>
      <p style="color:var(--silver); font-size:14px; margin-top:10px;">
        ${meRow.pts} pontos em 3 jogos (saldo ${meRow.gf - meRow.ga >= 0 ? "+" : ""}${meRow.gf - meRow.ga}). Os dois primeiros do grupo avançam aos 16-avos.
      </p>
      <div class="match-actions">
        <button class="btn btn-primary" id="btn-go-knockout">Ir para os 16-avos de final →</button>
      </div>
    `;
    $("#btn-go-knockout").addEventListener("click", () => {
      showScreen("#screen-knockout");
      renderKnockoutTrack();
      renderKnockoutMatchScreen();
    });
  } else {
    card.innerHTML = `
      <div class="match-stage-label">FIM DA FASE DE GRUPOS</div>
      <div class="match-verdict lose" style="margin-top:6px;">Eliminado — ${pos}º lugar no grupo.</div>
      <p style="color:var(--silver); font-size:14px; margin-top:10px;">
        ${meRow.pts} pontos em 3 jogos (saldo ${meRow.gf - meRow.ga >= 0 ? "+" : ""}${meRow.gf - meRow.ga}). Só os dois primeiros avançam — sua campanha termina aqui.
      </p>
      <div class="match-actions">
        <button class="btn btn-primary" id="btn-see-summary-group">Ver resumo da campanha →</button>
      </div>
    `;
    $("#btn-see-summary-group").addEventListener("click", renderSummary);
  }
}

/* ---------- TELA: MATA-MATA ---------- */
function renderKnockoutTrack() {
  const track = $("#tournament-track-ko");
  track.innerHTML = "";
  STAGES.filter((s) => !s.group).forEach((s) => {
    const div = document.createElement("div");
    div.className = "tt-stage";
    div.textContent = s.label;
    track.appendChild(div);
  });
  updateKnockoutTrackStatus();
}
function updateKnockoutTrackStatus() {
  const els = document.querySelectorAll("#tournament-track-ko .tt-stage");
  const koResults = state.results.slice(3);
  els.forEach((el, i) => {
    el.classList.remove("done", "fail", "live");
    if (i < koResults.length) {
      el.classList.add(koResults[i].won ? "done" : "fail");
    } else if (i === koResults.length) {
      el.classList.add("live");
    }
  });
}

function renderKnockoutMatchScreen() {
  $("#knockout-meta").innerHTML = `<span>OVR ${currentSquadOvr().toFixed(1)}</span>`;
  const stageIdx = state.results.length; // 3..7

  if (stageIdx >= 8 || isEliminated()) {
    renderSummary();
    return;
  }

  const stage = STAGES[stageIdx];
  const koIndex = stageIdx - 3;
  const rival = state.knockoutRivals[koIndex];
  const myOvr = currentSquadOvr();
  const rivalOvr = avgClubOvr(rival);

  const card = $("#knockout-match-card");
  card.innerHTML = `
    <div class="match-stage-label">${stage.label}</div>
    <div class="match-teams">
      <div class="match-side">
        <div class="badge">★</div>
        <h4>${state.teamName}</h4>
        <div class="ovr">OVR ${myOvr.toFixed(1)}</div>
      </div>
      <div class="match-score"><span>?</span><span class="vs">x</span><span>?</span></div>
      <div class="match-side">
        <div class="badge">${rival.badge}</div>
        <h4>${rival.club}</h4>
        <div class="ovr">OVR ${rivalOvr.toFixed(0)} · ${rival.season}</div>
      </div>
    </div>
    <div class="match-actions">
      <button class="btn btn-primary" id="btn-play-ko-match">Apitar o jogo →</button>
    </div>
  `;
  $("#btn-play-ko-match").addEventListener("click", () => playKnockoutCurrentMatch(stageIdx));
}

function playKnockoutCurrentMatch(stageIdx) {
  const btn = $("#btn-play-ko-match");
  if (!btn || btn.dataset.running === "1") return; // proteção contra double-click
  btn.dataset.running = "1";
  btn.disabled = true;
  btn.textContent = "Simulando...";
  setTimeout(() => {
    if (state.results.length !== stageIdx) return;
    const record = playKnockoutMatch(stageIdx);
    renderKnockoutMatchResult(record);
    updateKnockoutTrackStatus();
  }, 600);
}

function buildPenaltyShootoutHtml(record) {
  if (!record.penalties || !record.penalties.rounds) return "";
  const rounds = record.penalties.rounds;

  const items = rounds
    .map((r) => {
      const isMine = r.side === "me";
      const teamLabel = isMine ? state.teamName : record.rivalLabel;
      const icon = r.scored ? "✓" : "✗";
      const statusClass = r.scored ? "pk-scored" : "pk-missed";
      return `
        <div class="pk-round ${isMine ? "pk-mine" : "pk-rival"}">
          <span class="pk-round-num">${r.round}ª</span>
          <span class="pk-shooter">${r.shooter}</span>
          <span class="pk-team-tag">${teamLabel}</span>
          <span class="pk-status ${statusClass}">${icon}</span>
        </div>
      `;
    })
    .join("");

  return `
    <div class="pk-shootout">
      <h5>Disputa de Pênaltis · ${record.penalties.my} x ${record.penalties.rival}</h5>
      <div class="pk-list">${items}</div>
    </div>
  `;
}

function renderKnockoutMatchResult(record) {
  const card = $("#knockout-match-card");
  const isLast = state.results.length >= 8;
  const eliminated = isEliminated();

  let pkLine = "";
  if (record.penalties) {
    pkLine = `<div class="match-pk">Pênaltis: ${record.penalties.my} x ${record.penalties.rival}</div>`;
  }

  let verdict = "";
  if (record.won) verdict = `<div class="match-verdict win">Vitória! ${state.teamName} avança.</div>`;
  else verdict = `<div class="match-verdict lose">Derrota. Fim da campanha.</div>`;

  card.innerHTML = `
    <div class="match-stage-label">${record.stage.label}</div>
    <div class="match-teams">
      <div class="match-side">
        <div class="badge">★</div>
        <h4>${state.teamName}</h4>
        <div class="ovr">OVR ${record.myOvr.toFixed(0)}</div>
      </div>
      <div class="match-score"><span>${record.myGoals}</span><span class="vs">x</span><span>${record.rivalGoals}</span></div>
      <div class="match-side">
        <div class="badge">${record.rivalBadge}</div>
        <h4>${record.rivalLabel}</h4>
        <div class="ovr">OVR ${record.rivalOvr.toFixed(0)}</div>
      </div>
    </div>
    ${pkLine}
    ${verdict}
    ${buildGoalEventsHtml(record)}
    ${buildPenaltyShootoutHtml(record)}
    <div class="match-actions">
      ${
        eliminated || isLast
          ? `<button class="btn btn-primary" id="btn-see-summary-ko">Ver resumo da campanha →</button>`
          : `<button class="btn btn-primary" id="btn-next-ko">Próximo jogo →</button>`
      }
    </div>
  `;

  if (eliminated || isLast) {
    $("#btn-see-summary-ko").addEventListener("click", renderSummary);
  } else {
    $("#btn-next-ko").addEventListener("click", renderKnockoutMatchScreen);
  }
}

/* ---------- TELA: RESUMO FINAL ---------- */
function renderSummary() {
  showScreen("#screen-summary");

  const perfect = isPerfectRun();
  const wins = state.results.filter((r) => r.won).length;
  const eliminatedEarly = state.results.length < 8;

  $("#summary-tag").textContent = perfect
    ? "PERFEIÇÃO ABSOLUTA · 8 A 0"
    : eliminatedEarly
    ? "ELIMINADO"
    : "CAMPANHA ENCERRADA";

  $("#summary-score").innerHTML = `<span>${state.goalsFor}</span><span style="color:var(--silver); font-size:0.5em;">x</span><span>${state.goalsAgainst}</span>`;
  $("#summary-team").textContent = `★ ${state.teamName} · ${wins} vitória(s) em ${state.results.length} jogo(s)`;

  const table = $("#results-table");
  table.innerHTML = `
    <div class="rt-row header">
      <span>Adversário</span>
      <span>Fase</span>
      <span>Placar</span>
      <span>Resultado</span>
    </div>
  `;
  state.results.forEach((r) => {
    const row = document.createElement("div");
    row.className = "rt-row";
    const scoreText = r.penalties
      ? `${r.myGoals}-${r.rivalGoals} (${r.penalties.my}-${r.penalties.rival} pên.)`
      : `${r.myGoals}-${r.rivalGoals}`;
    row.innerHTML = `
      <span><span class="rt-badge-icon">${r.rivalBadge}</span>${r.rivalLabel}</span>
      <span>${r.stage.label}</span>
      <span class="rt-score">${scoreText}</span>
      <span class="rt-badge ${r.won ? "win" : r.draw ? "draw" : "lose"}">${r.won ? "Vitória" : r.draw ? "Empate" : "Derrota"}</span>
    `;
    table.appendChild(row);
  });

  renderCampaignStats();
}

function renderCampaignStats() {
  const stats = computeCampaignStats();

  const statsRow = $("#summary-stats-row");
  const scorerHtml = stats.topScorer
    ? `
      <div class="stat-card">
        <span class="stat-card-label">Artilheiro</span>
        <span class="stat-card-name">${stats.topScorer.name}</span>
        <span class="stat-card-value">${stats.topScorer.goals} gol${stats.topScorer.goals === 1 ? "" : "s"}</span>
      </div>
    `
    : `
      <div class="stat-card stat-card-empty">
        <span class="stat-card-label">Artilheiro</span>
        <span class="stat-card-name">—</span>
        <span class="stat-card-value">Nenhum gol marcado</span>
      </div>
    `;
  const assisterHtml = stats.topAssister
    ? `
      <div class="stat-card">
        <span class="stat-card-label">Maior Assistente</span>
        <span class="stat-card-name">${stats.topAssister.name}</span>
        <span class="stat-card-value">${stats.topAssister.assists} assist${stats.topAssister.assists === 1 ? "ência" : "ências"}</span>
      </div>
    `
    : `
      <div class="stat-card stat-card-empty">
        <span class="stat-card-label">Maior Assistente</span>
        <span class="stat-card-name">—</span>
        <span class="stat-card-value">Nenhuma assistência</span>
      </div>
    `;
  statsRow.innerHTML = scorerHtml + assisterHtml;

  const squadCard = $("#summary-squad-card");
  const rowsHtml = stats.squadStats
    .map(
      (p) => `
        <div class="squad-stat-row">
          <span class="ssr-pos">${p.pos}</span>
          <span class="ssr-name">${p.name}</span>
          <span class="ssr-goals">${p.goals ? `⚽ ${p.goals}` : ""}</span>
          <span class="ssr-assists">${p.assists ? `🅰️ ${p.assists}` : ""}</span>
          <span class="ssr-ovr">${p.ovr}</span>
        </div>
      `
    )
    .join("");
  squadCard.innerHTML = `
    <h3>Elenco · ${state.teamName}</h3>
    <div class="squad-stat-row header">
      <span>Pos</span>
      <span>Jogador</span>
      <span></span>
      <span></span>
      <span>OVR</span>
    </div>
    ${rowsHtml}
  `;
}

$("#btn-play-again").addEventListener("click", () => {
  resetGame();
  selectedFormation = "4-3-3";
  $("#team-name-input").value = "";
  showScreen("#screen-mode");
  renderFormationGrid();
});
