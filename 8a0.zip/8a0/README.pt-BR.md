# 8a0 ⚽

Um jogo de montar time dos sonhos da Champions League, direto no navegador. Sorteie clube por clube, monte sua escalação ideal, e tente fazer 8 a 0.

[🇬🇧 English version](README.md)

---

## O que é isso?

Você escala 11 jogadores entre 60 clubes-temporada reais da Champions League / Copa dos Campeões, indo dos anos 1950 até os anos 2020 — da final 7x3 do Real Madrid em 1960 até a era moderna do PSG. A cada rodada, um clube é sorteado e você escolhe qualquer jogador do elenco completo pra qualquer posição compatível no seu time. Nenhum jogador real pode ser escalado duas vezes.

Com o time montado, você disputa 8 partidas: 3 jogos de fase de grupos, depois 16-avos até a final. Vença todas as 8 e você conseguiu — uma campanha perfeita de 8 a 0.

## Como jogar

1. **Escolha o nome do time e a formação** — 9 formações táticas disponíveis (4-3-3, 4-2-3-1, 4-4-2, 3-5-2, 3-4-3, 4-1-4-1, 5-3-2, 4-1-2-1-2, 3-4-2-1). Fica travada assim que o draft começa.
2. **Escolha o modo:**
   - **Clássico** — overalls visíveis o tempo todo, draft com informação completa.
   - **Challenge** — overalls escondidos até o time estar completo. Você escala às cegas, só pelo nome e posição, e tem uma grande revelação no final.
3. **Draft** — 11 rodadas. Cada rodada oferece o elenco completo de um clube; escolha qualquer jogador compatível com uma vaga livre ou ocupada. Dá pra reorganizar jogadores entre vagas compatíveis a qualquer momento.
4. **Fase de grupos** — 3 jogos contra 3 clubes rivais. Os rivais também jogam entre si progressivamente, um confronto extra revelado junto com cada um dos seus jogos, então a tabela fica totalmente real no final.
5. **Mata-mata** — 16-avos, oitavas, quartas, semi, final. Empates vão pra disputa de pênaltis completa, cobrança por cobrança.
6. **Resumo final** — artilheiro, maior assistente, e as estatísticas/overalls de todo o elenco, ordenados por posição do goleiro ao atacante.

## Funcionalidades

- **60 clubes-temporada**, todos participantes reais da Champions League / Copa dos Campeões Europeus (com duas exceções sinalizadas explicitamente para elencos lendários que nunca chegaram a uma final)
- **9 formações**, cada uma com seu próprio layout de campo
- Jogadores que aparecem em mais de um clube-temporada têm overalls diferenciados refletindo a fase da carreira (revelação jovem vs. auge vs. veterano)
- **Disputa de pênaltis realista** — atacantes e meias cobram primeiro, chance de conversão varia com o overall, lados alternados, morte súbita de verdade sem corte artificial
- Eventos de gol detalhados, com artilheiro, assistência e minuto
- Tabela de grupo progressiva — os confrontos entre rivais acontecem ao longo das 3 rodadas, não tudo de uma vez
- Balanceado para que uma campanha perfeita de 8 a 0 aconteça em cerca de 1–3% das vezes

## Como rodar

É um site estático — sem build, sem servidor necessário.

```bash
# só abrir
open index.html
```

Ou sirva localmente se preferir:

```bash
python3 -m http.server 8000
# depois acesse localhost:8000
```

## Estrutura do projeto

```
8a0/
├── index.html          # as 5 telas (landing, escolha de modo, draft, grupo, mata-mata, resumo)
├── assets/
│   ├── data.js           # base de dados de clubes-temporada, formações, lógica de compatibilidade de posição
│   ├── engine.js          # estado do jogo, lógica de draft, simulação de partidas, classificação
│   ├── ui.js               # renderização e eventos
│   ├── style.css           # tema visual
│   └── images/
```

## Aviso

Projeto de fã não oficial. Dados de jogadores e overalls são aproximados, feitos para entretenimento — não são um registro histórico ou estatístico preciso.
