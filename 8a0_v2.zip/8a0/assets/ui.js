/* ============================================================
   8A0 — UI / CONTROLLER
   ============================================================ */

function $(sel) {
  return document.querySelector(sel);
}
function showScreen(id) {
  document.querySelectorAll(".screen").forEach((s) => s.classList.remove("active"));
  $(id).classList.add("active");
}
function lastName(full) {
  const parts = full.split(" ");
  return parts[parts.length - 1];
}

/* ---------- estrelinhas decorativas do hero ---------- */
(function seedStars() {
  const box = $("#stars-bg");
  if (!box) return;
  for (let i = 0; i < 18; i++) {
    const s = document.createElement("span");
    s.style.left = Math.random() * 100 + "%";
    s.style.top = Math.random() * 100 + "%";
    s.style.opacity = (0.2 + Math.random() * 0.6).toFixed(2);
    box.appendChild(s);
  }
})();

/* ---------- TELA: LANDING -> DRAFT ---------- */
$("#btn-start").addEventListener("click", () => {
  initBuilder();
  showScreen("#screen-draft");
  renderDraft();
});

/* ---------- TELA: DRAFT (sorteio + escolha, tudo numa tela) ---------- */
function renderDraft() {
  $("#draft-meta").innerHTML = `<span>FORMAÇÃO ${state.myFormation}</span><span>OVR ${currentSquadOvr() ? currentSquadOvr().toFixed(1) : "0"}</span>`;
  renderPitchSlots();
  renderOfferZone();
  renderSquadMiniList();

  $("#draft-count").textContent = `${state.draftIndex}/11`;

  if (isDraftComplete()) {
    $("#offer-zone").innerHTML = `<p style="color:var(--silver); font-size:13px;">Time completo! Você já pode seguir pra Champions.</p>`;
    $("#draft-actions").style.display = "flex";
  } else {
    $("#draft-actions").style.display = "none";
  }
}

function renderPitchSlots() {
  const board = $("#pitch-board");
  board.querySelectorAll(".slot").forEach((el) => el.remove());

  state.slots.forEach((slot) => {
    const el = document.createElement("div");
    el.className = "slot " + (slot.player ? "filled" : "empty");
    el.style.left = slot.x + "%";
    el.style.top = slot.y + "%";
    el.innerHTML = `
      <div class="slot-dot">
        ${slot.player ? slot.player.ovr : slot.pos}
        ${slot.player ? `<span class="slot-ovr-badge">${slot.pos}</span>` : ""}
      </div>
      <div class="slot-name">${slot.player ? lastName(slot.player.name) : slot.pos}</div>
    `;
    board.appendChild(el);
  });
}

function renderOfferZone() {
  const zone = $("#offer-zone");
  if (!state.currentOffer || isDraftComplete()) {
    zone.innerHTML = "";
    return;
  }
  const cs = state.currentOffer.clubSeason;
  const eligible = eligibleOfferPlayers();

  let html = `
    <div class="offer-card">
      <div class="offer-club">${cs.badge} ${cs.club}</div>
      <div class="offer-season">TEMPORADA ${cs.season} · ESCOLHA 1 JOGADOR</div>
      <div class="offer-list">
  `;

  eligible
    .sort((a, b) => b.ovr - a.ovr)
    .forEach((p, idx) => {
      const isLegend = p.ovr >= 90;
      html += `
        <div class="offer-item ${isLegend ? "legend" : ""}" data-idx="${idx}">
          <div class="oi-left">
            <span class="oi-name">${p.name}</span>
            <div class="oi-positions">
              ${p.positions.map((pos) => `<span class="oi-pos">${pos}</span>`).join("")}
            </div>
          </div>
          <span class="oi-ovr">${p.ovr}</span>
        </div>
      `;
    });

  html += `</div></div>`;
  zone.innerHTML = html;

  // liga clique: ao clicar no jogador, mostra os slots elegíveis dele pra escolher onde entra
  const items = zone.querySelectorAll(".offer-item");
  items.forEach((item, idx) => {
    item.addEventListener("click", () => {
      const player = eligible.sort((a, b) => b.ovr - a.ovr)[idx];
      openSlotPicker(item, player);
    });
  });
}

function openSlotPicker(itemEl, player) {
  // remove pickers abertos antes
  document.querySelectorAll(".slot-pick-row").forEach((r) => r.remove());

  const row = document.createElement("div");
  row.className = "slot-pick-row";
  player.__eligibleSlots.forEach((slotPos) => {
    const btn = document.createElement("button");
    btn.className = "slot-pick-btn";
    btn.textContent = `Escalar em ${slotPos}`;
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      draftPlayerIntoSlot(player, slotPos);
      renderDraft();
    });
    row.appendChild(btn);
  });
  itemEl.appendChild(row);
}

function renderSquadMiniList() {
  const list = $("#squad-mini-list");
  list.innerHTML = "";
  if (!state.squadPlayers.length) return;
  state.slots
    .filter((s) => s.player)
    .forEach((s) => {
      const row = document.createElement("div");
      row.className = "smi-row";
      row.innerHTML = `<span>${s.pos}</span><b>${s.player.name} · ${s.player.ovr}</b>`;
      list.appendChild(row);
    });
}

$("#btn-go-championship").addEventListener("click", () => {
  generateChampionship();
  showScreen("#screen-group");
  renderGroupTrack();
  renderGroupTable();
  renderGroupMatchScreen();
});

/* ---------- TELA: FASE DE GRUPOS ---------- */
function renderGroupTrack() {
  const track = $("#tournament-track-group");
  track.innerHTML = "";
  STAGES.filter((s) => s.group).forEach((s, i) => {
    const div = document.createElement("div");
    div.className = "tt-stage";
    div.textContent = s.label;
    track.appendChild(div);
  });
  updateGroupTrackStatus();
}
function updateGroupTrackStatus() {
  const els = document.querySelectorAll("#tournament-track-group .tt-stage");
  els.forEach((el, i) => {
    el.classList.remove("done", "fail", "live");
    if (i < state.results.length) {
      el.classList.add(state.results[i].won ? "done" : state.results[i].draw ? "" : "fail");
    } else if (i === state.results.length) {
      el.classList.add("live");
    }
  });
}

function renderGroupTable() {
  const card = $("#group-table-card");
  const standing = computeGroupStanding();
  let html = `<h3>Classificação do Grupo</h3>`;
  html += `<div class="gt-row header"><span>Time</span><span>J</span><span>SG</span><span>GP</span><span>Pts</span></div>`;
  standing.sorted.forEach((row, i) => {
    const pos = i + 1;
    const qualified = pos <= 2;
    html += `
      <div class="gt-row ${row.isMe ? "me" : ""} ${qualified ? "gt-qualified" : "gt-eliminated-row"}">
        <span class="gt-team"><span class="gt-pos">${pos}º</span>${row.isMe ? "★ Meu Time" : (row.club.badge + " " + row.name)}</span>
        <span class="gt-num">${row.played}</span>
        <span class="gt-num">${row.gf - row.ga >= 0 ? "+" : ""}${row.gf - row.ga}</span>
        <span class="gt-num">${row.gf}</span>
        <span class="gt-pts">${row.pts}</span>
      </div>
    `;
  });
  card.innerHTML = html;
}

function renderGroupMatchScreen() {
  $("#group-meta").innerHTML = `<span>OVR ${currentSquadOvr().toFixed(1)}</span>`;
  const stageIdx = state.results.length;

  if (stageIdx >= 3) {
    // fim dos 3 jogos: decide classificação
    const standing = computeGroupStanding();
    renderGroupResultGate(standing);
    return;
  }

  const stage = STAGES[stageIdx];
  const rival = state.groupTeams[stageIdx];
  const myOvr = currentSquadOvr();
  const rivalOvr = avgClubOvr(rival);

  const card = $("#group-match-card");
  card.innerHTML = `
    <div class="match-stage-label">${stage.label}</div>
    <div class="match-teams">
      <div class="match-side">
        <div class="badge">★</div>
        <h4>Meu Time</h4>
        <div class="ovr">OVR ${myOvr.toFixed(1)}</div>
      </div>
      <div class="match-score"><span>?</span><span class="vs">x</span><span>?</span></div>
      <div class="match-side">
        <div class="badge">${rival.badge}</div>
        <h4>${rival.club}</h4>
        <div class="ovr">OVR ${rivalOvr.toFixed(0)} · ${rival.season}</div>
      </div>
    </div>
    <div class="match-actions">
      <button class="btn btn-primary" id="btn-play-group-match">Apitar o jogo →</button>
    </div>
  `;
  $("#btn-play-group-match").addEventListener("click", () => playGroupCurrentMatch(stageIdx));
}

function playGroupCurrentMatch(stageIdx) {
  const btn = $("#btn-play-group-match");
  btn.disabled = true;
  btn.textContent = "Simulando...";
  setTimeout(() => {
    const record = playGroupMatch(stageIdx);
    renderGroupMatchResult(record);
    updateGroupTrackStatus();
    renderGroupTable();
  }, 600);
}

function buildGoalEventsHtml(record) {
  const myList = record.myEvents.length
    ? record.myEvents
        .map(
          (ev) =>
            `<div class="ge-event"><span class="ge-min">${ev.minute}'</span><span>⚽ ${ev.scorer}${ev.assister ? `<span class="ge-assist"> (assist. ${ev.assister})</span>` : ""}</span></div>`
        )
        .join("")
    : `<div class="ge-event" style="color:var(--silver);">Sem gols</div>`;

  const rivalList = record.rivalEvents.length
    ? record.rivalEvents
        .map(
          (ev) =>
            `<div class="ge-event"><span class="ge-min">${ev.minute}'</span><span>⚽ ${ev.scorer}${ev.assister ? `<span class="ge-assist"> (assist. ${ev.assister})</span>` : ""}</span></div>`
        )
        .join("")
    : `<div class="ge-event" style="color:var(--silver);">Sem gols</div>`;

  return `
    <div class="goal-events">
      <div class="ge-col">
        <h5>Gols · Meu Time</h5>
        ${myList}
      </div>
      <div class="ge-col">
        <h5>Gols · ${record.rivalLabel}</h5>
        ${rivalList}
      </div>
    </div>
  `;
}

function renderGroupMatchResult(record) {
  const card = $("#group-match-card");
  let verdict = "";
  if (record.won) verdict = `<div class="match-verdict win">Vitória!</div>`;
  else if (record.draw) verdict = `<div class="match-verdict">Empate.</div>`;
  else verdict = `<div class="match-verdict lose">Derrota.</div>`;

  card.innerHTML = `
    <div class="match-stage-label">${record.stage.label}</div>
    <div class="match-teams">
      <div class="match-side">
        <div class="badge">★</div>
        <h4>Meu Time</h4>
        <div class="ovr">OVR ${record.myOvr.toFixed(0)}</div>
      </div>
      <div class="match-score"><span>${record.myGoals}</span><span class="vs">x</span><span>${record.rivalGoals}</span></div>
      <div class="match-side">
        <div class="badge">${record.rivalBadge}</div>
        <h4>${record.rivalLabel}</h4>
        <div class="ovr">OVR ${record.rivalOvr.toFixed(0)}</div>
      </div>
    </div>
    ${verdict}
    ${buildGoalEventsHtml(record)}
    <div class="match-actions">
      <button class="btn btn-primary" id="btn-next-group">${state.results.length >= 3 ? "Ver classificação final do grupo →" : "Próximo jogo do grupo →"}</button>
    </div>
  `;
  $("#btn-next-group").addEventListener("click", renderGroupMatchScreen);
}

/* depois dos 3 jogos: mostra se classificou ou foi eliminado matematicamente
   pela posição na tabela (não pelo resultado de um jogo isolado) */
function renderGroupResultGate(standing) {
  const card = $("#group-match-card");
  const meRow = standing.sorted.find((r) => r.isMe);
  const pos = standing.myPos;

  if (standing.qualified) {
    card.innerHTML = `
      <div class="match-stage-label">FIM DA FASE DE GRUPOS</div>
      <div class="match-verdict win" style="margin-top:6px;">Classificado em ${pos}º lugar!</div>
      <p style="color:var(--silver); font-size:14px; margin-top:10px;">
        ${meRow.pts} pontos em 3 jogos (saldo ${meRow.gf - meRow.ga >= 0 ? "+" : ""}${meRow.gf - meRow.ga}). Os dois primeiros do grupo avançam aos 16-avos.
      </p>
      <div class="match-actions">
        <button class="btn btn-primary" id="btn-go-knockout">Ir para os 16-avos de final →</button>
      </div>
    `;
    $("#btn-go-knockout").addEventListener("click", () => {
      showScreen("#screen-knockout");
      renderKnockoutTrack();
      renderKnockoutMatchScreen();
    });
  } else {
    card.innerHTML = `
      <div class="match-stage-label">FIM DA FASE DE GRUPOS</div>
      <div class="match-verdict lose" style="margin-top:6px;">Eliminado — ${pos}º lugar no grupo.</div>
      <p style="color:var(--silver); font-size:14px; margin-top:10px;">
        ${meRow.pts} pontos em 3 jogos (saldo ${meRow.gf - meRow.ga >= 0 ? "+" : ""}${meRow.gf - meRow.ga}). Só os dois primeiros avançam — sua campanha termina aqui.
      </p>
      <div class="match-actions">
        <button class="btn btn-primary" id="btn-see-summary-group">Ver resumo da campanha →</button>
      </div>
    `;
    $("#btn-see-summary-group").addEventListener("click", renderSummary);
  }
}

/* ---------- TELA: MATA-MATA ---------- */
function renderKnockoutTrack() {
  const track = $("#tournament-track-ko");
  track.innerHTML = "";
  STAGES.filter((s) => !s.group).forEach((s) => {
    const div = document.createElement("div");
    div.className = "tt-stage";
    div.textContent = s.label;
    track.appendChild(div);
  });
  updateKnockoutTrackStatus();
}
function updateKnockoutTrackStatus() {
  const els = document.querySelectorAll("#tournament-track-ko .tt-stage");
  const koResults = state.results.slice(3);
  els.forEach((el, i) => {
    el.classList.remove("done", "fail", "live");
    if (i < koResults.length) {
      el.classList.add(koResults[i].won ? "done" : "fail");
    } else if (i === koResults.length) {
      el.classList.add("live");
    }
  });
}

function renderKnockoutMatchScreen() {
  $("#knockout-meta").innerHTML = `<span>OVR ${currentSquadOvr().toFixed(1)}</span>`;
  const stageIdx = state.results.length; // 3..7

  if (stageIdx >= 8 || isEliminated()) {
    renderSummary();
    return;
  }

  const stage = STAGES[stageIdx];
  const koIndex = stageIdx - 3;
  const rival = state.knockoutRivals[koIndex];
  const myOvr = currentSquadOvr();
  const rivalOvr = avgClubOvr(rival);

  const card = $("#knockout-match-card");
  card.innerHTML = `
    <div class="match-stage-label">${stage.label}</div>
    <div class="match-teams">
      <div class="match-side">
        <div class="badge">★</div>
        <h4>Meu Time</h4>
        <div class="ovr">OVR ${myOvr.toFixed(1)}</div>
      </div>
      <div class="match-score"><span>?</span><span class="vs">x</span><span>?</span></div>
      <div class="match-side">
        <div class="badge">${rival.badge}</div>
        <h4>${rival.club}</h4>
        <div class="ovr">OVR ${rivalOvr.toFixed(0)} · ${rival.season}</div>
      </div>
    </div>
    <div class="match-actions">
      <button class="btn btn-primary" id="btn-play-ko-match">Apitar o jogo →</button>
    </div>
  `;
  $("#btn-play-ko-match").addEventListener("click", () => playKnockoutCurrentMatch(stageIdx));
}

function playKnockoutCurrentMatch(stageIdx) {
  const btn = $("#btn-play-ko-match");
  btn.disabled = true;
  btn.textContent = "Simulando...";
  setTimeout(() => {
    const record = playKnockoutMatch(stageIdx);
    renderKnockoutMatchResult(record);
    updateKnockoutTrackStatus();
  }, 600);
}

function renderKnockoutMatchResult(record) {
  const card = $("#knockout-match-card");
  const isLast = state.results.length >= 8;
  const eliminated = isEliminated();

  let pkLine = "";
  if (record.penalties) {
    pkLine = `<div class="match-pk">Pênaltis: ${record.penalties.my} x ${record.penalties.rival}</div>`;
  }

  let verdict = "";
  if (record.won) verdict = `<div class="match-verdict win">Vitória! Meu Time avança.</div>`;
  else verdict = `<div class="match-verdict lose">Derrota. Fim da campanha.</div>`;

  card.innerHTML = `
    <div class="match-stage-label">${record.stage.label}</div>
    <div class="match-teams">
      <div class="match-side">
        <div class="badge">★</div>
        <h4>Meu Time</h4>
        <div class="ovr">OVR ${record.myOvr.toFixed(0)}</div>
      </div>
      <div class="match-score"><span>${record.myGoals}</span><span class="vs">x</span><span>${record.rivalGoals}</span></div>
      <div class="match-side">
        <div class="badge">${record.rivalBadge}</div>
        <h4>${record.rivalLabel}</h4>
        <div class="ovr">OVR ${record.rivalOvr.toFixed(0)}</div>
      </div>
    </div>
    ${pkLine}
    ${verdict}
    ${buildGoalEventsHtml(record)}
    <div class="match-actions">
      ${
        eliminated || isLast
          ? `<button class="btn btn-primary" id="btn-see-summary-ko">Ver resumo da campanha →</button>`
          : `<button class="btn btn-primary" id="btn-next-ko">Próximo jogo →</button>`
      }
    </div>
  `;

  if (eliminated || isLast) {
    $("#btn-see-summary-ko").addEventListener("click", renderSummary);
  } else {
    $("#btn-next-ko").addEventListener("click", renderKnockoutMatchScreen);
  }
}

/* ---------- TELA: RESUMO FINAL ---------- */
function renderSummary() {
  showScreen("#screen-summary");

  const perfect = isPerfectRun();
  const wins = state.results.filter((r) => r.won).length;
  const eliminatedEarly = state.results.length < 8;

  $("#summary-tag").textContent = perfect
    ? "PERFEIÇÃO ABSOLUTA · 8 A 0"
    : eliminatedEarly
    ? "ELIMINADO"
    : "CAMPANHA ENCERRADA";

  $("#summary-score").innerHTML = `<span>${state.goalsFor}</span><span style="color:var(--silver); font-size:0.5em;">x</span><span>${state.goalsAgainst}</span>`;
  $("#summary-team").textContent = `★ Meu Time · ${wins} vitória(s) em ${state.results.length} jogo(s)`;

  const table = $("#results-table");
  table.innerHTML = `
    <div class="rt-row header">
      <span>Adversário</span>
      <span>Fase</span>
      <span>Placar</span>
      <span>Resultado</span>
    </div>
  `;
  state.results.forEach((r) => {
    const row = document.createElement("div");
    row.className = "rt-row";
    const scoreText = r.penalties
      ? `${r.myGoals}-${r.rivalGoals} (${r.penalties.my}-${r.penalties.rival} pên.)`
      : `${r.myGoals}-${r.rivalGoals}`;
    row.innerHTML = `
      <span><span class="rt-badge-icon">${r.rivalBadge}</span>${r.rivalLabel}</span>
      <span>${r.stage.label}</span>
      <span class="rt-score">${scoreText}</span>
      <span class="rt-badge ${r.won ? "win" : r.draw ? "draw" : "lose"}">${r.won ? "Vitória" : r.draw ? "Empate" : "Derrota"}</span>
    `;
    table.appendChild(row);
  });
}

$("#btn-play-again").addEventListener("click", () => {
  resetGame();
  initBuilder();
  showScreen("#screen-draft");
  renderDraft();
});
