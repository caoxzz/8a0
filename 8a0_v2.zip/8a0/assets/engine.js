/* ============================================================
   8A0 — MOTOR DO JOGO (CHAMPIONS)
   8 jogos: 3 de grupo + 16-avos + oitavas + quartas + semi + final
   ============================================================ */

const STAGES = [
  { key: "g1", label: "Grupo · Jogo 1", group: true },
  { key: "g2", label: "Grupo · Jogo 2", group: true },
  { key: "g3", label: "Grupo · Jogo 3", group: true },
  { key: "r32", label: "16-avos de Final", group: false },
  { key: "r16", label: "Oitavas de Final", group: false },
  { key: "qf", label: "Quartas de Final", group: false },
  { key: "sf", label: "Semifinal", group: false },
  { key: "final", label: "Final", group: false },
];

const state = {
  // modo de jogo
  gameMode: "classic", // "classic" (overs visíveis) | "challenge" (overs escondidos até time completo)

  // montagem
  slotsOrder: [], // ordem dos slots a preencher (índices em FORMATION padrão fixa do jogador)
  myFormation: "4-3-3",
  slots: [], // { pos, x, y, player: {...}|null }
  draftIndex: 0, // quantos picks já foram feitos (0..10)
  currentOffer: null, // { clubSeason, slotPos } oferta atual de sorteio
  squadPlayers: [], // jogadores escolhidos, na ordem do draft

  // campeonato
  groupTeams: [], // 3 rivais do grupo (clube-temporada)
  groupTable: [], // pontos/saldo de cada um incl. "eu"
  knockoutRivals: [], // 5 rivais do mata-mata (16-avos..final)
  results: [], // registros partida a partida
  currentStage: 0,
  goalsFor: 0,
  goalsAgainst: 0,
  eliminatedAt: null, // index do stage onde foi eliminado, ou null
};

function rand(min, max) {
  return Math.random() * (max - min) + min;
}
function randInt(min, max) {
  return Math.floor(rand(min, max + 1));
}
function pick(arr) {
  return arr[randInt(0, arr.length - 1)];
}
function pickN(arr, n) {
  const copy = [...arr];
  const out = [];
  while (out.length < n && copy.length) {
    out.push(copy.splice(randInt(0, copy.length - 1), 1)[0]);
  }
  return out;
}

/* ---------- MONTAGEM: minha formação fixa de referência ---------- */
const MY_FORMATION = "4-3-3";
const MY_SLOTS_TEMPLATE = FORMATION_COORDS[MY_FORMATION];

function initBuilder() {
  state.myFormation = MY_FORMATION;
  state.slots = MY_SLOTS_TEMPLATE.map((c) => ({ pos: c.pos, x: c.x, y: c.y, player: null }));
  state.draftIndex = 0;
  state.squadPlayers = [];
  state.currentOffer = null;
  state.revealedAfterDraft = false;
  rollNextOffer();
}

/* sorteia o próximo clube-temporada e oferece o elenco completo dele.
   O usuário pode escolher qualquer jogador pra qualquer slot compatível
   — vazio, ou ocupado (desde que o ocupante possa ser deslocado pra
   outra vaga dele mesmo). */
function rollNextOffer() {
  if (state.draftIndex >= 11) {
    state.currentOffer = null;
    return null;
  }
  const used = new Set(state.squadPlayers.map((p) => p.__clubKey));
  let pool = CLUB_SEASONS.filter((c) => !used.has(c.club + c.season));
  if (!pool.length) pool = CLUB_SEASONS;

  // sorteia até achar um clube com pelo menos 1 jogador realmente
  // escalável agora (evita oferta "morta" sem ninguém disponível)
  let attempts = 0;
  let clubSeason = pick(pool);
  while (attempts < 30) {
    const hasEligible = clubSeason.squad.some((p) => computeEligibleSlotsForNewPlayer(p).length > 0);
    if (hasEligible) break;
    clubSeason = pick(pool);
    attempts++;
  }

  state.currentOffer = { clubSeason };
  return state.currentOffer;
}

function emptySlots() {
  return state.slots.filter((s) => !s.player);
}

/* posições vagas compatíveis com um jogador, EXCLUINDO a posição de slot
   informada (usado pra achar "pra onde mover" alguém que está sendo
   deslocado de um slot específico) */
function vacantCompatibleSlots(player, excludeSlotIndex) {
  return state.slots
    .map((s, idx) => ({ s, idx }))
    .filter(({ s, idx }) => !s.player && idx !== excludeSlotIndex && slotAcceptsPlayer(s.pos, player));
}

/* pode esse jogador (que ocupa slotIndex) ser deslocado pra alguma outra
   posição vaga compatível com ele? */
function canRelocate(slotIndex) {
  const slot = state.slots[slotIndex];
  if (!slot.player) return false;
  return vacantCompatibleSlots(slot.player, slotIndex).length > 0;
}

/* jogadores do clube ofertado, com status pra cada slot do time:
   se cabe vazio, se cabe deslocando o ocupante, ou se é impossível */
function eligibleOfferPlayers() {
  if (!state.currentOffer) return [];
  return state.currentOffer.clubSeason.squad.map((p) => {
    const enriched = {
      ...p,
      __clubKey: state.currentOffer.clubSeason.club + state.currentOffer.clubSeason.season,
      __club: state.currentOffer.clubSeason.club,
      __season: state.currentOffer.clubSeason.season,
      __badge: state.currentOffer.clubSeason.badge,
    };
    enriched.__eligibleSlots = computeEligibleSlotsForNewPlayer(enriched);
    return enriched;
  });
}

/* pra um jogador NOVO (do draft), calcula em quais slots ele pode entrar:
   - jogador já escalado em algum slot (mesmo nome, de outro clube-temporada
     sorteado antes) -> nunca elegível, evita duplicar a mesma pessoa
   - slot vazio compatível -> sempre elegível
   - slot ocupado compatível -> elegível SE o ocupante puder ser deslocado
     pra outro lugar vago dele mesmo (excluindo esse slot) */
function computeEligibleSlotsForNewPlayer(player) {
  const alreadyOnTeam = state.slots.some((s) => s.player && s.player.name === player.name);
  if (alreadyOnTeam) return [];

  const out = [];
  state.slots.forEach((slot, idx) => {
    if (!slotAcceptsPlayer(slot.pos, player)) return;
    if (!slot.player) {
      out.push({ pos: slot.pos, slotIndex: idx, displaces: null });
    } else {
      const canMove = vacantCompatibleSlots(slot.player, idx).length > 0;
      if (canMove) {
        out.push({ pos: slot.pos, slotIndex: idx, displaces: slot.player });
      }
      // se não pode mover o ocupante, esse slot fica indisponível pra esse jogador
    }
  });
  return out;
}

/* confirma escolha: jogador novo entra no slotIndex. Se havia alguém lá,
   esse alguém é OBRIGATORIAMENTE realocado pra uma vaga compatível dele
   (a escolha de qual vaga é decidida automaticamente já que só há uma
   forma de o slot ser elegível: existir ao menos 1 vaga pra ele. Se houver
   mais de uma vaga possível, pega a primeira disponível). */
function draftPlayerIntoSlot(player, slotIndex) {
  const slot = state.slots[slotIndex];
  if (!slotAcceptsPlayer(slot.pos, player)) return false;

  // trava de segurança: nunca permite escalar o mesmo jogador (por nome)
  // duas vezes, mesmo que tenha sido oferecido via clubes diferentes
  const alreadyOnTeam = state.slots.some((s) => s.player && s.player.name === player.name);
  if (alreadyOnTeam) return false;

  if (slot.player) {
    const vacancies = vacantCompatibleSlots(slot.player, slotIndex);
    if (!vacancies.length) return false; // não pode descartar: bloqueia a troca
    const displaced = slot.player;
    const targetIdx = vacancies[0].idx;
    state.slots[targetIdx].player = displaced;
  }

  state.slots[slotIndex].player = player;
  state.squadPlayers.push(player);
  state.draftIndex++;
  rollNextOffer();
  return true;
}

/* ---------- REORGANIZAÇÃO MANUAL (jogador já escalado, fora do draft) ----------
   Move o jogador do slot `fromIndex` pro slot `toIndex` (que deve estar
   vazio e compatível). Usado quando o usuário clica num slot ocupado e
   quer realocar manualmente ANTES de uma nova oferta entrar ali. */
function manuallyRelocatePlayer(fromIndex, toIndex) {
  const fromSlot = state.slots[fromIndex];
  const toSlot = state.slots[toIndex];
  if (!fromSlot.player || toSlot.player) return false;
  if (!slotAcceptsPlayer(toSlot.pos, fromSlot.player)) return false;
  toSlot.player = fromSlot.player;
  fromSlot.player = null;
  return true;
}

function isDraftComplete() {
  return state.draftIndex >= 11 && state.slots.every((s) => s.player);
}

function currentSquadOvr() {
  const filled = state.slots.filter((s) => s.player);
  if (!filled.length) return 0;
  return filled.reduce((s, sl) => s + sl.player.ovr, 0) / filled.length;
}

/* ---------- GERAÇÃO DO CAMPEONATO ---------- */
function generateChampionship() {
  const usedKeys = new Set(state.squadPlayers.map((p) => p.__clubKey));
  const pool = CLUB_SEASONS.filter((c) => !usedKeys.has(c.club + c.season));

  const chosen = pickN(pool, 8);
  // 3 times de grupo (mais fracos/médios) + 5 do mata-mata (crescente)
  chosen.sort((a, b) => avgClubOvr(a) - avgClubOvr(b));
  state.groupTeams = chosen.slice(0, 3);
  state.knockoutRivals = chosen.slice(3, 8);

  // tabela de grupo: eu + 3 rivais
  state.groupTable = [
    { isMe: true, name: "Meu Time", pts: 0, gf: 0, ga: 0, played: 0 },
    ...state.groupTeams.map((t) => ({
      isMe: false,
      name: `${t.club} ${t.season}`,
      club: t,
      pts: 0,
      gf: 0,
      ga: 0,
      played: 0,
    })),
  ];

  state.results = [];
  state.currentStage = 0;
  state.goalsFor = 0;
  state.goalsAgainst = 0;
  state.eliminatedAt = null;
}

function avgClubOvr(clubSeason) {
  const top11 = [...clubSeason.squad].sort((a, b) => b.ovr - a.ovr).slice(0, 11);
  return top11.reduce((s, p) => s + p.ovr, 0) / top11.length;
}

/* ---------- SIMULAÇÃO DE PARTIDA (com artilheiros/assistências) ---------- */
function strengthToLambda(ovr) {
  return Math.max(0.35, (ovr - 60) / 12);
}

function poissonGoals(lambda) {
  let goals = 0;
  let chancesLeft = 7;
  while (chancesLeft > 0) {
    const p = lambda / 7;
    if (Math.random() < p) goals++;
    chancesLeft--;
  }
  if (lambda > 2.5 && Math.random() < 0.25) goals++;
  return goals;
}

/* escolhe artilheiro/assistente pra cada gol, pesando por posição
   (atacantes/pontas marcam mais, meias/laterais assistem mais) */
function weightForScorer(player) {
  const fam = POS_FAMILY[player.positions[0]] || "MEIO";
  if (fam === "ATQ") return 5;
  if (fam === "MEIO") return 2;
  if (fam === "DEF") return 0.6;
  return 0.1; // goleiro praticamente não marca
}
function weightForAssister(player) {
  const fam = POS_FAMILY[player.positions[0]] || "MEIO";
  if (fam === "MEIO") return 4;
  if (fam === "ATQ") return 3;
  if (fam === "DEF") return 1.5;
  return 0.1;
}

function weightedPick(players, weightFn) {
  const total = players.reduce((s, p) => s + weightFn(p), 0);
  let r = rand(0, total);
  for (const p of players) {
    r -= weightFn(p);
    if (r <= 0) return p;
  }
  return players[players.length - 1];
}

function generateGoalEvents(goals, squad, isMine) {
  const events = [];
  const fieldPlayers = squad.filter((p) => p.positions[0] !== "GOL");
  for (let i = 0; i < goals; i++) {
    const scorer = weightedPick(fieldPlayers.length ? fieldPlayers : squad, weightForScorer);
    let assister = null;
    if (Math.random() < 0.78) {
      const candidates = fieldPlayers.filter((p) => p.name !== scorer.name);
      if (candidates.length) assister = weightedPick(candidates, weightForAssister);
    }
    events.push({
      scorer: scorer.name,
      assister: assister ? assister.name : null,
      minute: randInt(1, 90),
    });
  }
  events.sort((a, b) => a.minute - b.minute);
  return events;
}

function myActiveSquad() {
  return state.slots.map((s) => s.player);
}

function simulateOneMatch(rivalClubSeason) {
  const myOvr = currentSquadOvr();
  const rivalOvr = avgClubOvr(rivalClubSeason);
  const diff = myOvr - rivalOvr;
  // bônus "dream team": um time montado escolhendo o melhor de cada posição
  // joga mais coeso do que a média sugere, então o efeito da vantagem de OVR
  // é amplificado e ganha um impulso fixo de coesão tática
  const myLambda = strengthToLambda(myOvr) + Math.max(0, diff / 13) + 0.45;
  const rivalLambda = Math.max(0.25, strengthToLambda(rivalOvr) + Math.max(0, -diff / 26) - 0.2);
  const myGoals = poissonGoals(myLambda);
  const rivalGoals = poissonGoals(rivalLambda);

  const myEvents = generateGoalEvents(myGoals, myActiveSquad(), true);
  const rivalEvents = generateGoalEvents(rivalGoals, rivalClubSeason.squad, false);

  return { myGoals, rivalGoals, myOvr, rivalOvr, myEvents, rivalEvents };
}

/* ---------- JOGOS DE GRUPO (com tabela de classificação) ---------- */
function playGroupMatch(stageIndex) {
  const rivalEntry = state.groupTeams[stageIndex];
  const sim = simulateOneMatch(rivalEntry);

  // atualiza tabela: eu
  const meRow = state.groupTable.find((r) => r.isMe);
  meRow.gf += sim.myGoals;
  meRow.ga += sim.rivalGoals;
  meRow.played++;
  if (sim.myGoals > sim.rivalGoals) meRow.pts += 3;
  else if (sim.myGoals === sim.rivalGoals) meRow.pts += 1;

  const rivalRow = state.groupTable.find((r) => !r.isMe && r.club === rivalEntry);
  rivalRow.gf += sim.rivalGoals;
  rivalRow.ga += sim.myGoals;
  rivalRow.played++;
  if (sim.rivalGoals > sim.myGoals) rivalRow.pts += 3;
  else if (sim.myGoals === sim.rivalGoals) rivalRow.pts += 1;

  const record = {
    stage: STAGES[stageIndex],
    rivalLabel: `${rivalEntry.club} ${rivalEntry.season}`,
    rivalBadge: rivalEntry.badge,
    ...sim,
    won: sim.myGoals > sim.rivalGoals,
    draw: sim.myGoals === sim.rivalGoals,
    penalties: null,
  };
  state.results.push(record);
  state.goalsFor += sim.myGoals;
  state.goalsAgainst += sim.rivalGoals;
  state.currentStage++;
  return record;
}

/* depois dos 3 jogos de grupo, checa classificação por pontos/saldo */
function isGroupStageDone() {
  return state.results.length >= 3 && state.results.slice(0, 3).every((r) => r.stage.group);
}

function computeGroupStanding() {
  const sorted = [...state.groupTable].sort((a, b) => {
    if (b.pts !== a.pts) return b.pts - a.pts;
    const aSaldo = a.gf - a.ga;
    const bSaldo = b.gf - b.ga;
    if (bSaldo !== aSaldo) return bSaldo - aSaldo;
    return b.gf - a.gf;
  });
  const myPos = sorted.findIndex((r) => r.isMe) + 1; // 1..4
  // top 2 do grupo avançam (estilo Champions clássica)
  return { sorted, myPos, qualified: myPos <= 2 };
}

/* ---------- MATA-MATA ---------- */
function playKnockoutMatch(stageIndex) {
  const koIndex = stageIndex - 3; // 0..4 dentro de knockoutRivals
  const rivalEntry = state.knockoutRivals[koIndex];
  const sim = simulateOneMatch(rivalEntry);

  let penalties = null;
  let won = sim.myGoals > sim.rivalGoals;
  if (sim.myGoals === sim.rivalGoals) {
    const myOvr = sim.myOvr,
      rivalOvr = sim.rivalOvr;
    const myPK = randInt(2, 5) + (myOvr >= rivalOvr ? 1 : 0);
    const rivalPK = randInt(2, 5) + (rivalOvr > myOvr ? 1 : 0);
    penalties = myPK === rivalPK ? { my: myPK + 1, rival: rivalPK } : { my: myPK, rival: rivalPK };
    won = penalties.my > penalties.rival;
  }

  const record = {
    stage: STAGES[stageIndex],
    rivalLabel: `${rivalEntry.club} ${rivalEntry.season}`,
    rivalBadge: rivalEntry.badge,
    ...sim,
    won,
    draw: false,
    penalties,
  };
  state.results.push(record);
  state.goalsFor += sim.myGoals;
  state.goalsAgainst += sim.rivalGoals;
  state.currentStage++;
  if (!won) state.eliminatedAt = stageIndex;
  return record;
}

function isEliminated() {
  return state.eliminatedAt !== null;
}

function isPerfectRun() {
  // 8-0 perfeito: passou em 1º do grupo (ou 2º, mas vencendo os 3 jogos)
  // E venceu todos os 5 mata-matas sem pênaltis decidindo (vitória "seca" é o ideal,
  // mas vamos considerar perfeito = venceu todos os 8 jogos, grupo + mata-mata)
  if (state.results.length !== 8) return false;
  return state.results.every((r) => r.won);
}

function resetGame() {
  state.slotsOrder = [];
  state.myFormation = MY_FORMATION;
  state.slots = [];
  state.draftIndex = 0;
  state.currentOffer = null;
  state.squadPlayers = [];
  state.revealedAfterDraft = false;
  state.groupTeams = [];
  state.groupTable = [];
  state.knockoutRivals = [];
  state.results = [];
  state.currentStage = 0;
  state.goalsFor = 0;
  state.goalsAgainst = 0;
  state.eliminatedAt = null;
}
